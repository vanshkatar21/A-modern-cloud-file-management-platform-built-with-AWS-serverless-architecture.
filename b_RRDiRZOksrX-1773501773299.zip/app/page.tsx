"use client"

import { motion } from "framer-motion"
import { Navbar } from "@/components/navbar"
import { FloatingClouds } from "@/components/floating-clouds"
import { GlowButton } from "@/components/glow-button"
import { FeatureCard } from "@/components/feature-card"
import { StatsSection } from "@/components/stats-section"
import { ArchitectureDiagram } from "@/components/architecture-diagram"
import { Footer } from "@/components/footer"
import { 
  Cloud, 
  Shield, 
  Zap, 
  Share2, 
  BarChart3, 
  Lock,
  Upload,
  Globe
} from "lucide-react"
import Link from "next/link"

const features = [
  {
    icon: <Cloud size={28} />,
    title: "AWS S3 Storage",
    description: "Unlimited scalable storage with 99.999999999% durability and automatic redundancy."
  },
  {
    icon: <Shield size={28} />,
    title: "Enterprise Security",
    description: "256-bit AES encryption at rest and in transit with AWS Cognito authentication."
  },
  {
    icon: <Zap size={28} />,
    title: "Serverless Lambda",
    description: "Lightning-fast serverless compute with automatic scaling and zero cold starts."
  },
  {
    icon: <Share2 size={28} />,
    title: "Secure Sharing",
    description: "Generate secure, time-limited sharing links with granular access controls."
  },
  {
    icon: <BarChart3 size={28} />,
    title: "Real-time Analytics",
    description: "Comprehensive CloudWatch monitoring with detailed usage insights and reports."
  },
  {
    icon: <Globe size={28} />,
    title: "Global CDN",
    description: "CloudFront edge locations worldwide for ultra-low latency file delivery."
  },
]

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-gradient-animated overflow-hidden">
      <FloatingClouds />
      <Navbar />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            {/* Badge */}
            <motion.div
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <span className="w-2 h-2 rounded-full bg-neon-cyan animate-pulse" />
              <span className="text-sm text-muted-foreground">Powered by AWS Cloud Services</span>
            </motion.div>

            {/* Main heading */}
            <motion.h1
              className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight mb-6"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <span className="text-foreground">The Future of</span>
              <br />
              <span className="text-gradient">Cloud Storage</span>
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              A serverless cloud platform for secure file storage, management, and sharing. 
              Built on enterprise-grade AWS infrastructure with AI-powered intelligence.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              className="flex flex-col sm:flex-row gap-4 justify-center"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <Link href="/signup">
                <GlowButton variant="primary" size="lg">
                  <Upload className="mr-2 inline" size={20} />
                  Start Uploading Free
                </GlowButton>
              </Link>
              <Link href="/dashboard">
                <GlowButton variant="outline" size="lg">
                  View Dashboard
                </GlowButton>
              </Link>
            </motion.div>

            {/* Floating preview card */}
            <motion.div
              className="mt-16 relative"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
            >
              <div className="relative max-w-4xl mx-auto">
                {/* Glow effect behind */}
                <div className="absolute inset-0 bg-gradient-to-r from-neon-blue/30 via-neon-cyan/30 to-neon-purple/30 blur-3xl" />
                
                {/* Preview card */}
                <motion.div
                  className="relative glass-card rounded-2xl p-4 md:p-6"
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                >
                  {/* Mock dashboard preview */}
                  <div className="aspect-video rounded-xl bg-card/80 p-4 md:p-6 overflow-hidden">
                    {/* Mock header */}
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-3 h-3 rounded-full bg-destructive" />
                        <div className="w-3 h-3 rounded-full bg-chart-4" />
                        <div className="w-3 h-3 rounded-full bg-chart-2" />
                      </div>
                      <div className="flex gap-2">
                        <div className="w-20 h-6 rounded bg-muted animate-pulse" />
                        <div className="w-20 h-6 rounded bg-neon-blue/30" />
                      </div>
                    </div>
                    
                    {/* Mock content grid */}
                    <div className="grid grid-cols-3 gap-4">
                      {[1, 2, 3, 4, 5, 6].map((i) => (
                        <motion.div
                          key={i}
                          className="aspect-square rounded-lg bg-muted/50 flex items-center justify-center"
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: 0.8 + i * 0.1 }}
                        >
                          <Cloud className="text-muted-foreground/50" size={24} />
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="w-6 h-10 rounded-full border-2 border-muted-foreground/30 flex justify-center pt-2">
            <motion.div
              className="w-1 h-2 rounded-full bg-neon-cyan"
              animate={{ y: [0, 12, 0], opacity: [1, 0.3, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </div>
        </motion.div>
      </section>

      {/* Stats Section */}
      <StatsSection />

      {/* Features Section */}
      <section id="features" className="py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gradient mb-4">
              Powerful Features
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Everything you need to store, manage, and share files securely in the cloud
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <FeatureCard
                key={feature.title}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                delay={index * 0.1}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Architecture Section */}
      <ArchitectureDiagram />

      {/* CTA Section */}
      <section className="py-20 relative">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="relative glass-card rounded-3xl p-8 md:p-12 text-center overflow-hidden"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            {/* Background glow */}
            <div className="absolute inset-0 bg-gradient-to-r from-neon-blue/10 via-neon-cyan/10 to-neon-purple/10" />
            
            <div className="relative">
              <Lock className="w-12 h-12 mx-auto mb-6 text-neon-cyan" />
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Ready to Transform Your Cloud Experience?
              </h2>
              <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
                Join thousands of users who trust CloudSync AI for their secure cloud storage needs. 
                Start with 10GB free storage today.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/signup">
                  <GlowButton variant="primary" size="lg">
                    Get Started Free
                  </GlowButton>
                </Link>
                <Link href="/contact">
                  <GlowButton variant="outline" size="lg">
                    Contact Sales
                  </GlowButton>
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
