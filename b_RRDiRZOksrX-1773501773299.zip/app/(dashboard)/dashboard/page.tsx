"use client"

import { motion } from "framer-motion"
import { DashboardHeader } from "@/components/dashboard-header"
import {
  Cloud,
  Upload,
  Download,
  Share2,
  FileText,
  Image,
  Film,
  Music,
  FolderOpen,
  TrendingUp,
  Clock,
  Star,
} from "lucide-react"
import Link from "next/link"

const statsCards = [
  {
    icon: Cloud,
    label: "Total Storage",
    value: "4.2 GB",
    subtext: "of 10 GB used",
    color: "from-neon-blue to-neon-cyan",
    trend: "+12%",
  },
  {
    icon: FileText,
    label: "Total Files",
    value: "1,234",
    subtext: "files uploaded",
    color: "from-neon-cyan to-neon-purple",
    trend: "+8%",
  },
  {
    icon: Share2,
    label: "Shared Links",
    value: "56",
    subtext: "active shares",
    color: "from-neon-purple to-neon-blue",
    trend: "+23%",
  },
  {
    icon: Download,
    label: "Downloads",
    value: "892",
    subtext: "this month",
    color: "from-chart-4 to-chart-2",
    trend: "+5%",
  },
]

const recentFiles = [
  { name: "Project_Proposal.pdf", type: "document", size: "2.4 MB", modified: "2 hours ago", icon: FileText },
  { name: "Design_Assets.zip", type: "archive", size: "156 MB", modified: "5 hours ago", icon: FolderOpen },
  { name: "Team_Photo.jpg", type: "image", size: "4.2 MB", modified: "1 day ago", icon: Image },
  { name: "Presentation.mp4", type: "video", size: "89 MB", modified: "2 days ago", icon: Film },
  { name: "Podcast_Episode.mp3", type: "audio", size: "45 MB", modified: "3 days ago", icon: Music },
]

const quickActions = [
  { icon: Upload, label: "Upload Files", href: "/upload", color: "from-neon-blue to-neon-cyan" },
  { icon: FolderOpen, label: "Browse Files", href: "/files", color: "from-neon-cyan to-neon-purple" },
  { icon: Share2, label: "Share Link", href: "/files", color: "from-neon-purple to-neon-blue" },
]

const activityTimeline = [
  { action: "Uploaded", file: "Project_Proposal.pdf", time: "2 hours ago" },
  { action: "Shared", file: "Design_Assets.zip", time: "5 hours ago" },
  { action: "Downloaded", file: "Team_Photo.jpg", time: "1 day ago" },
  { action: "Deleted", file: "Old_Backup.zip", time: "2 days ago" },
]

export default function DashboardPage() {
  return (
    <div className="min-h-screen">
      <DashboardHeader title="Dashboard" subtitle="Welcome back, John!" />

      <div className="p-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {statsCards.map((stat, index) => (
            <motion.div
              key={stat.label}
              className="glass-card rounded-2xl p-5 relative overflow-hidden group"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -4 }}
            >
              {/* Background gradient */}
              <div
                className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-10 transition-opacity`}
              />

              <div className="relative flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
                  <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{stat.subtext}</p>
                </div>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                  <stat.icon className="text-primary-foreground" size={20} />
                </div>
              </div>

              {/* Trend */}
              <div className="relative flex items-center gap-1 mt-3 text-chart-2 text-sm">
                <TrendingUp size={14} />
                <span>{stat.trend} from last month</span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Quick Actions & Activity */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Quick Actions */}
          <motion.div
            className="glass-card rounded-2xl p-5"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
            <div className="space-y-3">
              {quickActions.map((action) => (
                <Link key={action.label} href={action.href}>
                  <motion.div
                    className="flex items-center gap-4 p-3 rounded-xl hover:bg-muted/50 transition-colors cursor-pointer"
                    whileHover={{ x: 4 }}
                  >
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${action.color} flex items-center justify-center`}>
                      <action.icon className="text-primary-foreground" size={18} />
                    </div>
                    <span className="font-medium text-foreground">{action.label}</span>
                  </motion.div>
                </Link>
              ))}
            </div>
          </motion.div>

          {/* Recent Activity Timeline */}
          <motion.div
            className="lg:col-span-2 glass-card rounded-2xl p-5"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-foreground">Recent Activity</h3>
              <Clock className="text-muted-foreground" size={18} />
            </div>
            <div className="space-y-4">
              {activityTimeline.map((activity, index) => (
                <motion.div
                  key={index}
                  className="flex items-center gap-4"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + index * 0.1 }}
                >
                  <div className="w-2 h-2 rounded-full bg-neon-cyan" />
                  <div className="flex-1">
                    <p className="text-sm text-foreground">
                      <span className="text-muted-foreground">{activity.action}</span>{" "}
                      <span className="font-medium">{activity.file}</span>
                    </p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Recent Files */}
        <motion.div
          className="glass-card rounded-2xl p-5"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-foreground">Recent Files</h3>
            <Link href="/files" className="text-sm text-neon-cyan hover:underline">
              View all
            </Link>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-sm text-muted-foreground border-b border-border">
                  <th className="pb-3 font-medium">Name</th>
                  <th className="pb-3 font-medium hidden md:table-cell">Type</th>
                  <th className="pb-3 font-medium">Size</th>
                  <th className="pb-3 font-medium hidden sm:table-cell">Modified</th>
                  <th className="pb-3 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {recentFiles.map((file, index) => (
                  <motion.tr
                    key={file.name}
                    className="border-b border-border/50 hover:bg-muted/30 transition-colors"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.8 + index * 0.05 }}
                  >
                    <td className="py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                          <file.icon className="text-neon-cyan" size={18} />
                        </div>
                        <span className="font-medium text-foreground">{file.name}</span>
                      </div>
                    </td>
                    <td className="py-3 text-muted-foreground capitalize hidden md:table-cell">{file.type}</td>
                    <td className="py-3 text-muted-foreground">{file.size}</td>
                    <td className="py-3 text-muted-foreground hidden sm:table-cell">{file.modified}</td>
                    <td className="py-3">
                      <div className="flex items-center gap-2">
                        <motion.button
                          className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                        >
                          <Download size={16} />
                        </motion.button>
                        <motion.button
                          className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                        >
                          <Share2 size={16} />
                        </motion.button>
                        <motion.button
                          className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-chart-4"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                        >
                          <Star size={16} />
                        </motion.button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
