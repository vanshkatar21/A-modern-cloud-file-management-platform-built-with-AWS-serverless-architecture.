"use client"

import { motion } from "framer-motion"
import { DashboardHeader } from "@/components/dashboard-header"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend,
  LineChart,
  Line,
} from "recharts"
import {
  TrendingUp,
  TrendingDown,
  Download,
  Upload,
  Eye,
  Share2,
  HardDrive,
  Users,
  FileText,
  Calendar,
} from "lucide-react"

const storageData = [
  { name: "Jan", used: 1.2, total: 10 },
  { name: "Feb", used: 1.8, total: 10 },
  { name: "Mar", used: 2.4, total: 10 },
  { name: "Apr", used: 2.9, total: 10 },
  { name: "May", used: 3.4, total: 10 },
  { name: "Jun", used: 4.2, total: 10 },
]

const fileTypeData = [
  { name: "Documents", value: 35, color: "oklch(0.65 0.25 260)" },
  { name: "Images", value: 28, color: "oklch(0.75 0.18 200)" },
  { name: "Videos", value: 20, color: "oklch(0.6 0.25 300)" },
  { name: "Audio", value: 10, color: "oklch(0.75 0.18 180)" },
  { name: "Others", value: 7, color: "oklch(0.5 0.1 260)" },
]

const activityData = [
  { name: "Mon", uploads: 24, downloads: 18 },
  { name: "Tue", uploads: 35, downloads: 28 },
  { name: "Wed", uploads: 42, downloads: 35 },
  { name: "Thu", uploads: 28, downloads: 22 },
  { name: "Fri", uploads: 56, downloads: 48 },
  { name: "Sat", uploads: 18, downloads: 12 },
  { name: "Sun", uploads: 12, downloads: 8 },
]

const bandwidthData = [
  { name: "00:00", value: 120 },
  { name: "04:00", value: 80 },
  { name: "08:00", value: 250 },
  { name: "12:00", value: 380 },
  { name: "16:00", value: 420 },
  { name: "20:00", value: 300 },
  { name: "24:00", value: 180 },
]

const statsCards = [
  {
    icon: HardDrive,
    label: "Storage Used",
    value: "4.2 GB",
    change: "+12%",
    trend: "up",
    color: "from-neon-blue to-neon-cyan",
  },
  {
    icon: Upload,
    label: "Total Uploads",
    value: "1,234",
    change: "+8%",
    trend: "up",
    color: "from-neon-cyan to-neon-purple",
  },
  {
    icon: Download,
    label: "Total Downloads",
    value: "892",
    change: "-3%",
    trend: "down",
    color: "from-neon-purple to-neon-blue",
  },
  {
    icon: Share2,
    label: "Shared Files",
    value: "56",
    change: "+23%",
    trend: "up",
    color: "from-chart-4 to-chart-2",
  },
]

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="glass-card rounded-lg p-3 border border-border">
        <p className="text-sm font-medium text-foreground">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={index} className="text-sm text-muted-foreground">
            {entry.name}: {entry.value}
          </p>
        ))}
      </div>
    )
  }
  return null
}

export default function AnalyticsPage() {
  return (
    <div className="min-h-screen">
      <DashboardHeader title="Analytics" subtitle="Track your storage usage and activity" />

      <div className="p-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {statsCards.map((stat, index) => (
            <motion.div
              key={stat.label}
              className="glass-card rounded-2xl p-5 relative overflow-hidden group"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -4 }}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-10 transition-opacity`} />

              <div className="relative flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
                  <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                  <stat.icon className="text-primary-foreground" size={20} />
                </div>
              </div>

              <div className={`relative flex items-center gap-1 mt-3 text-sm ${stat.trend === "up" ? "text-chart-2" : "text-destructive"}`}>
                {stat.trend === "up" ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                <span>{stat.change} from last month</span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Charts Row 1 */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Storage Usage Chart */}
          <motion.div
            className="glass-card rounded-2xl p-6"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-foreground">Storage Usage</h3>
                <p className="text-sm text-muted-foreground">Monthly storage consumption</p>
              </div>
              <select className="px-3 py-1.5 rounded-lg bg-muted text-sm text-foreground border border-border">
                <option>Last 6 months</option>
                <option>Last year</option>
              </select>
            </div>

            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={storageData}>
                <defs>
                  <linearGradient id="storageGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.65 0.25 260)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="oklch(0.65 0.25 260)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.03 260)" />
                <XAxis dataKey="name" stroke="oklch(0.65 0.02 260)" fontSize={12} />
                <YAxis stroke="oklch(0.65 0.02 260)" fontSize={12} unit=" GB" />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="used"
                  stroke="oklch(0.65 0.25 260)"
                  strokeWidth={2}
                  fill="url(#storageGradient)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </motion.div>

          {/* File Types Distribution */}
          <motion.div
            className="glass-card rounded-2xl p-6"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-foreground">File Distribution</h3>
                <p className="text-sm text-muted-foreground">Files by type</p>
              </div>
            </div>

            <div className="flex items-center">
              <ResponsiveContainer width="50%" height={200}>
                <PieChart>
                  <Pie
                    data={fileTypeData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {fileTypeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>

              <div className="flex-1 space-y-3">
                {fileTypeData.map((item) => (
                  <div key={item.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="text-sm text-foreground">{item.name}</span>
                    </div>
                    <span className="text-sm text-muted-foreground">{item.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>

        {/* Charts Row 2 */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Activity Chart */}
          <motion.div
            className="glass-card rounded-2xl p-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-foreground">Weekly Activity</h3>
                <p className="text-sm text-muted-foreground">Uploads vs Downloads</p>
              </div>
            </div>

            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={activityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.03 260)" />
                <XAxis dataKey="name" stroke="oklch(0.65 0.02 260)" fontSize={12} />
                <YAxis stroke="oklch(0.65 0.02 260)" fontSize={12} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Bar dataKey="uploads" fill="oklch(0.65 0.25 260)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="downloads" fill="oklch(0.75 0.18 200)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Bandwidth Usage */}
          <motion.div
            className="glass-card rounded-2xl p-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-foreground">Bandwidth Usage</h3>
                <p className="text-sm text-muted-foreground">Today{"'"}s traffic (MB/s)</p>
              </div>
            </div>

            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={bandwidthData}>
                <defs>
                  <linearGradient id="bandwidthGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.6 0.25 300)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="oklch(0.6 0.25 300)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.03 260)" />
                <XAxis dataKey="name" stroke="oklch(0.65 0.02 260)" fontSize={12} />
                <YAxis stroke="oklch(0.65 0.02 260)" fontSize={12} />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="oklch(0.6 0.25 300)"
                  strokeWidth={2}
                  dot={{ fill: "oklch(0.6 0.25 300)", strokeWidth: 2 }}
                  activeDot={{ r: 6, fill: "oklch(0.6 0.25 300)" }}
                />
              </LineChart>
            </ResponsiveContainer>
          </motion.div>
        </div>

        {/* Recent Activity Table */}
        <motion.div
          className="glass-card rounded-2xl p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-foreground">Activity Log</h3>
              <p className="text-sm text-muted-foreground">Recent file operations</p>
            </div>
            <button className="text-sm text-neon-cyan hover:underline">View all</button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-sm text-muted-foreground border-b border-border">
                  <th className="pb-3 font-medium">Action</th>
                  <th className="pb-3 font-medium">File</th>
                  <th className="pb-3 font-medium hidden md:table-cell">Size</th>
                  <th className="pb-3 font-medium hidden sm:table-cell">User</th>
                  <th className="pb-3 font-medium">Time</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { action: "Upload", file: "Project_Proposal.pdf", size: "2.4 MB", user: "John Doe", time: "2 min ago", icon: Upload, color: "text-chart-2" },
                  { action: "Download", file: "Design_Assets.zip", size: "156 MB", user: "Jane Smith", time: "15 min ago", icon: Download, color: "text-neon-cyan" },
                  { action: "Share", file: "Team_Photo.jpg", size: "4.2 MB", user: "John Doe", time: "1 hour ago", icon: Share2, color: "text-neon-purple" },
                  { action: "View", file: "Meeting_Notes.pdf", size: "1.2 MB", user: "Alex Johnson", time: "2 hours ago", icon: Eye, color: "text-chart-4" },
                  { action: "Upload", file: "Presentation.mp4", size: "89 MB", user: "John Doe", time: "3 hours ago", icon: Upload, color: "text-chart-2" },
                ].map((activity, index) => (
                  <motion.tr
                    key={index}
                    className="border-b border-border/50 hover:bg-muted/30 transition-colors"
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.9 + index * 0.05 }}
                  >
                    <td className="py-3">
                      <div className="flex items-center gap-2">
                        <activity.icon className={activity.color} size={16} />
                        <span className="text-foreground">{activity.action}</span>
                      </div>
                    </td>
                    <td className="py-3">
                      <div className="flex items-center gap-2">
                        <FileText className="text-muted-foreground" size={16} />
                        <span className="text-foreground">{activity.file}</span>
                      </div>
                    </td>
                    <td className="py-3 text-muted-foreground hidden md:table-cell">{activity.size}</td>
                    <td className="py-3 hidden sm:table-cell">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-gradient-to-br from-neon-blue to-neon-purple flex items-center justify-center text-xs text-primary-foreground">
                          {activity.user.split(" ").map(n => n[0]).join("")}
                        </div>
                        <span className="text-muted-foreground">{activity.user}</span>
                      </div>
                    </td>
                    <td className="py-3">
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Calendar size={14} />
                        <span>{activity.time}</span>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
