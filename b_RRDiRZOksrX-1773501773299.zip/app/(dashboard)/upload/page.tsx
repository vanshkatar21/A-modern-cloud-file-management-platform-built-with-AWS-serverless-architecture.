"use client"

import { motion, AnimatePresence } from "framer-motion"
import { DashboardHeader } from "@/components/dashboard-header"
import { GlowButton } from "@/components/glow-button"
import { useState, useCallback, useRef } from "react"
import {
  Upload,
  Cloud,
  FileText,
  Image,
  Film,
  Music,
  Archive,
  X,
  CheckCircle,
  AlertCircle,
  Pause,
  Play,
  Trash2,
} from "lucide-react"

interface UploadFile {
  id: string
  file: File
  progress: number
  status: "pending" | "uploading" | "completed" | "error" | "paused"
  error?: string
}

const getFileIcon = (type: string) => {
  if (type.startsWith("image/")) return Image
  if (type.startsWith("video/")) return Film
  if (type.startsWith("audio/")) return Music
  if (type.includes("zip") || type.includes("rar") || type.includes("tar")) return Archive
  return FileText
}

const getFileColor = (type: string) => {
  if (type.startsWith("image/")) return "from-neon-purple to-neon-blue"
  if (type.startsWith("video/")) return "from-destructive to-chart-4"
  if (type.startsWith("audio/")) return "from-chart-2 to-neon-cyan"
  if (type.includes("zip") || type.includes("rar")) return "from-muted-foreground to-muted"
  return "from-neon-blue to-neon-cyan"
}

const formatFileSize = (bytes: number) => {
  if (bytes === 0) return "0 Bytes"
  const k = 1024
  const sizes = ["Bytes", "KB", "MB", "GB"]
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
}

export default function UploadPage() {
  const [isDragging, setIsDragging] = useState(false)
  const [files, setFiles] = useState<UploadFile[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const processFiles = useCallback((fileList: FileList) => {
    const newFiles: UploadFile[] = Array.from(fileList).map((file) => ({
      id: Math.random().toString(36).substr(2, 9),
      file,
      progress: 0,
      status: "pending" as const,
    }))
    setFiles((prev) => [...prev, ...newFiles])

    // Simulate upload for each file
    newFiles.forEach((uploadFile) => {
      simulateUpload(uploadFile.id)
    })
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragging(false)
      if (e.dataTransfer.files.length > 0) {
        processFiles(e.dataTransfer.files)
      }
    },
    [processFiles]
  )

  const handleFileSelect = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files.length > 0) {
        processFiles(e.target.files)
      }
    },
    [processFiles]
  )

  const simulateUpload = (id: string) => {
    setFiles((prev) =>
      prev.map((f) => (f.id === id ? { ...f, status: "uploading" as const } : f))
    )

    let progress = 0
    const interval = setInterval(() => {
      progress += Math.random() * 15

      if (progress >= 100) {
        clearInterval(interval)
        setFiles((prev) =>
          prev.map((f) =>
            f.id === id ? { ...f, progress: 100, status: "completed" as const } : f
          )
        )
      } else {
        setFiles((prev) =>
          prev.map((f) => (f.id === id ? { ...f, progress } : f))
        )
      }
    }, 200)
  }

  const removeFile = (id: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== id))
  }

  const togglePause = (id: string) => {
    setFiles((prev) =>
      prev.map((f) =>
        f.id === id
          ? {
              ...f,
              status: f.status === "paused" ? "uploading" : "paused",
            }
          : f
      )
    )
  }

  const completedCount = files.filter((f) => f.status === "completed").length
  const totalSize = files.reduce((acc, f) => acc + f.file.size, 0)

  return (
    <div className="min-h-screen">
      <DashboardHeader title="Upload Files" subtitle="Drag and drop or browse to upload" />

      <div className="p-6 max-w-4xl mx-auto">
        {/* Drop Zone */}
        <motion.div
          className={`relative rounded-3xl border-2 border-dashed p-12 transition-all duration-300 ${
            isDragging
              ? "border-neon-cyan bg-neon-cyan/10"
              : "border-border hover:border-neon-blue/50 glass-card"
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {/* Animated background when dragging */}
          <AnimatePresence>
            {isDragging && (
              <motion.div
                className="absolute inset-0 rounded-3xl overflow-hidden"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-neon-blue/20 via-neon-cyan/20 to-neon-purple/20 animate-gradient" />
                {[...Array(20)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute w-2 h-2 rounded-full bg-neon-cyan/50"
                    style={{
                      left: `${Math.random() * 100}%`,
                      top: `${Math.random() * 100}%`,
                    }}
                    animate={{
                      y: [0, -100],
                      opacity: [0, 1, 0],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: Math.random() * 2,
                    }}
                  />
                ))}
              </motion.div>
            )}
          </AnimatePresence>

          <div className="relative text-center">
            {/* Cloud icon */}
            <motion.div
              className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-neon-blue/20 to-neon-cyan/20 flex items-center justify-center"
              animate={{
                y: isDragging ? [0, -10, 0] : 0,
                scale: isDragging ? 1.1 : 1,
              }}
              transition={{ duration: 0.5 }}
            >
              <motion.div
                animate={{ y: isDragging ? [0, -5, 0] : 0 }}
                transition={{ duration: 1, repeat: isDragging ? Infinity : 0 }}
              >
                <Cloud className="text-neon-cyan" size={48} />
              </motion.div>
            </motion.div>

            <h2 className="text-2xl font-bold text-foreground mb-2">
              {isDragging ? "Drop your files here" : "Drag & Drop your files"}
            </h2>
            <p className="text-muted-foreground mb-6">
              or click to browse from your computer
            </p>

            <input
              ref={fileInputRef}
              type="file"
              multiple
              onChange={handleFileSelect}
              className="hidden"
            />

            <GlowButton
              variant="primary"
              size="lg"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="mr-2" size={20} />
              Browse Files
            </GlowButton>

            <p className="text-xs text-muted-foreground mt-6">
              Supports all file types up to 5GB per file
            </p>
          </div>
        </motion.div>

        {/* Upload Queue */}
        <AnimatePresence>
          {files.length > 0 && (
            <motion.div
              className="mt-8"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
            >
              {/* Queue header */}
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-foreground">
                    Upload Queue
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {completedCount} of {files.length} completed - {formatFileSize(totalSize)} total
                  </p>
                </div>
                <button
                  className="text-sm text-muted-foreground hover:text-destructive transition-colors"
                  onClick={() => setFiles([])}
                >
                  Clear all
                </button>
              </div>

              {/* File list */}
              <div className="space-y-3">
                {files.map((uploadFile, index) => {
                  const Icon = getFileIcon(uploadFile.file.type)
                  const colorClass = getFileColor(uploadFile.file.type)

                  return (
                    <motion.div
                      key={uploadFile.id}
                      className="glass-card rounded-xl p-4"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      transition={{ delay: index * 0.05 }}
                    >
                      <div className="flex items-center gap-4">
                        {/* File icon */}
                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${colorClass} flex items-center justify-center flex-shrink-0`}>
                          <Icon className="text-primary-foreground" size={20} />
                        </div>

                        {/* File info */}
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-foreground truncate">
                            {uploadFile.file.name}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {formatFileSize(uploadFile.file.size)}
                          </p>
                        </div>

                        {/* Progress / Status */}
                        <div className="flex items-center gap-3">
                          {uploadFile.status === "uploading" && (
                            <span className="text-sm text-neon-cyan">
                              {Math.round(uploadFile.progress)}%
                            </span>
                          )}
                          {uploadFile.status === "completed" && (
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{ type: "spring" }}
                            >
                              <CheckCircle className="text-chart-2" size={20} />
                            </motion.div>
                          )}
                          {uploadFile.status === "error" && (
                            <AlertCircle className="text-destructive" size={20} />
                          )}
                          {uploadFile.status === "paused" && (
                            <span className="text-sm text-chart-4">Paused</span>
                          )}
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-1">
                          {(uploadFile.status === "uploading" || uploadFile.status === "paused") && (
                            <motion.button
                              className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground"
                              onClick={() => togglePause(uploadFile.id)}
                              whileHover={{ scale: 1.1 }}
                              whileTap={{ scale: 0.9 }}
                            >
                              {uploadFile.status === "paused" ? (
                                <Play size={16} />
                              ) : (
                                <Pause size={16} />
                              )}
                            </motion.button>
                          )}
                          <motion.button
                            className="p-2 rounded-lg hover:bg-destructive/20 transition-colors text-muted-foreground hover:text-destructive"
                            onClick={() => removeFile(uploadFile.id)}
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                          >
                            {uploadFile.status === "completed" ? (
                              <X size={16} />
                            ) : (
                              <Trash2 size={16} />
                            )}
                          </motion.button>
                        </div>
                      </div>

                      {/* Progress bar */}
                      {(uploadFile.status === "uploading" || uploadFile.status === "paused") && (
                        <div className="mt-3 h-1.5 rounded-full bg-muted overflow-hidden">
                          <motion.div
                            className="h-full bg-gradient-to-r from-neon-blue via-neon-cyan to-neon-purple"
                            initial={{ width: 0 }}
                            animate={{ width: `${uploadFile.progress}%` }}
                            transition={{ duration: 0.3 }}
                          />
                        </div>
                      )}
                    </motion.div>
                  )
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Upload Tips */}
        <motion.div
          className="mt-8 grid md:grid-cols-3 gap-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          {[
            {
              title: "Secure Upload",
              description: "All files are encrypted with 256-bit AES during transfer",
            },
            {
              title: "Fast CDN",
              description: "Files are distributed globally via CloudFront CDN",
            },
            {
              title: "Auto-Organize",
              description: "AI automatically categorizes and tags your files",
            },
          ].map((tip, index) => (
            <div key={tip.title} className="glass-card rounded-xl p-4 text-center">
              <h4 className="font-medium text-foreground mb-1">{tip.title}</h4>
              <p className="text-sm text-muted-foreground">{tip.description}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  )
}
