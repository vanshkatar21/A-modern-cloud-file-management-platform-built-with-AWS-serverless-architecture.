"use client"

import { motion, AnimatePresence } from "framer-motion"
import { DashboardHeader } from "@/components/dashboard-header"
import { GlowButton } from "@/components/glow-button"
import { useState } from "react"
import {
  FolderOpen,
  FileText,
  Image,
  Film,
  Music,
  Archive,
  Download,
  Share2,
  Trash2,
  MoreVertical,
  Grid,
  List,
  Filter,
  SortAsc,
  Star,
  StarOff,
  Copy,
  Edit,
  Eye,
  ChevronRight,
  Plus,
} from "lucide-react"

interface FileItem {
  id: string
  name: string
  type: "folder" | "document" | "image" | "video" | "audio" | "archive"
  size: string
  modified: string
  starred: boolean
  shared: boolean
}

const mockFiles: FileItem[] = [
  { id: "1", name: "Documents", type: "folder", size: "2.4 GB", modified: "2 hours ago", starred: true, shared: false },
  { id: "2", name: "Images", type: "folder", size: "1.8 GB", modified: "5 hours ago", starred: false, shared: true },
  { id: "3", name: "Videos", type: "folder", size: "4.2 GB", modified: "1 day ago", starred: false, shared: false },
  { id: "4", name: "Project_Proposal.pdf", type: "document", size: "2.4 MB", modified: "2 hours ago", starred: true, shared: true },
  { id: "5", name: "Team_Photo.jpg", type: "image", size: "4.2 MB", modified: "1 day ago", starred: false, shared: false },
  { id: "6", name: "Presentation.mp4", type: "video", size: "89 MB", modified: "2 days ago", starred: false, shared: true },
  { id: "7", name: "Podcast_Episode.mp3", type: "audio", size: "45 MB", modified: "3 days ago", starred: true, shared: false },
  { id: "8", name: "Backup_2024.zip", type: "archive", size: "156 MB", modified: "1 week ago", starred: false, shared: false },
  { id: "9", name: "Design_Assets.zip", type: "archive", size: "89 MB", modified: "3 days ago", starred: false, shared: true },
  { id: "10", name: "Meeting_Notes.pdf", type: "document", size: "1.2 MB", modified: "4 hours ago", starred: true, shared: false },
  { id: "11", name: "Logo_Final.png", type: "image", size: "2.8 MB", modified: "2 days ago", starred: true, shared: true },
  { id: "12", name: "Music_Collection", type: "folder", size: "890 MB", modified: "1 week ago", starred: false, shared: false },
]

const fileTypeIcons: Record<string, typeof FileText> = {
  folder: FolderOpen,
  document: FileText,
  image: Image,
  video: Film,
  audio: Music,
  archive: Archive,
}

const fileTypeColors: Record<string, string> = {
  folder: "from-chart-4 to-chart-2",
  document: "from-neon-blue to-neon-cyan",
  image: "from-neon-purple to-neon-blue",
  video: "from-destructive to-chart-4",
  audio: "from-chart-2 to-neon-cyan",
  archive: "from-muted-foreground to-muted",
}

export default function FilesPage() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [selectedFiles, setSelectedFiles] = useState<string[]>([])
  const [contextMenu, setContextMenu] = useState<{ id: string; x: number; y: number } | null>(null)
  const [files, setFiles] = useState(mockFiles)

  const toggleFileSelection = (id: string) => {
    setSelectedFiles((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    )
  }

  const toggleStarred = (id: string) => {
    setFiles((prev) =>
      prev.map((f) => (f.id === id ? { ...f, starred: !f.starred } : f))
    )
  }

  const breadcrumbs = ["My Files", "Documents"]

  return (
    <div className="min-h-screen">
      <DashboardHeader title="File Manager" subtitle="Manage all your cloud files" />

      <div className="p-6">
        {/* Toolbar */}
        <motion.div
          className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {/* Breadcrumbs */}
          <div className="flex items-center gap-2 text-sm">
            {breadcrumbs.map((crumb, index) => (
              <div key={crumb} className="flex items-center gap-2">
                {index > 0 && <ChevronRight className="text-muted-foreground" size={14} />}
                <button
                  className={`hover:text-foreground transition-colors ${
                    index === breadcrumbs.length - 1 ? "text-foreground font-medium" : "text-muted-foreground"
                  }`}
                >
                  {crumb}
                </button>
              </div>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            {/* View toggle */}
            <div className="flex items-center glass rounded-lg p-1">
              <button
                className={`p-2 rounded-md transition-colors ${
                  viewMode === "grid" ? "bg-muted text-foreground" : "text-muted-foreground hover:text-foreground"
                }`}
                onClick={() => setViewMode("grid")}
              >
                <Grid size={18} />
              </button>
              <button
                className={`p-2 rounded-md transition-colors ${
                  viewMode === "list" ? "bg-muted text-foreground" : "text-muted-foreground hover:text-foreground"
                }`}
                onClick={() => setViewMode("list")}
              >
                <List size={18} />
              </button>
            </div>

            {/* Filter & Sort */}
            <button className="flex items-center gap-2 px-3 py-2 glass rounded-lg text-muted-foreground hover:text-foreground transition-colors">
              <Filter size={18} />
              <span className="hidden sm:inline">Filter</span>
            </button>
            <button className="flex items-center gap-2 px-3 py-2 glass rounded-lg text-muted-foreground hover:text-foreground transition-colors">
              <SortAsc size={18} />
              <span className="hidden sm:inline">Sort</span>
            </button>

            {/* New folder / Upload */}
            <GlowButton variant="primary" size="sm">
              <Plus size={18} className="mr-1" />
              <span className="hidden sm:inline">New</span>
            </GlowButton>
          </div>
        </motion.div>

        {/* Selected files actions */}
        <AnimatePresence>
          {selectedFiles.length > 0 && (
            <motion.div
              className="mb-6 p-4 glass-card rounded-xl flex items-center justify-between"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
            >
              <span className="text-sm text-foreground">
                {selectedFiles.length} file(s) selected
              </span>
              <div className="flex items-center gap-2">
                <button className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground">
                  <Download size={18} />
                </button>
                <button className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground">
                  <Share2 size={18} />
                </button>
                <button className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground">
                  <Copy size={18} />
                </button>
                <button className="p-2 rounded-lg hover:bg-destructive/20 transition-colors text-muted-foreground hover:text-destructive">
                  <Trash2 size={18} />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* File Grid / List */}
        {viewMode === "grid" ? (
          <motion.div
            className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4"
            initial="hidden"
            animate="visible"
            variants={{
              hidden: {},
              visible: { transition: { staggerChildren: 0.05 } },
            }}
          >
            {files.map((file) => {
              const Icon = fileTypeIcons[file.type]
              const isSelected = selectedFiles.includes(file.id)

              return (
                <motion.div
                  key={file.id}
                  className={`group relative glass-card rounded-2xl p-4 cursor-pointer transition-all ${
                    isSelected ? "ring-2 ring-neon-cyan" : ""
                  }`}
                  variants={{
                    hidden: { opacity: 0, scale: 0.9 },
                    visible: { opacity: 1, scale: 1 },
                  }}
                  whileHover={{ y: -4 }}
                  onClick={() => toggleFileSelection(file.id)}
                >
                  {/* Star button */}
                  <motion.button
                    className={`absolute top-2 right-2 p-1.5 rounded-lg transition-all ${
                      file.starred ? "text-chart-4" : "text-muted-foreground opacity-0 group-hover:opacity-100"
                    }`}
                    onClick={(e) => {
                      e.stopPropagation()
                      toggleStarred(file.id)
                    }}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    {file.starred ? <Star size={16} fill="currentColor" /> : <StarOff size={16} />}
                  </motion.button>

                  {/* File icon */}
                  <div className={`w-14 h-14 mx-auto mb-3 rounded-xl bg-gradient-to-br ${fileTypeColors[file.type]} flex items-center justify-center`}>
                    <Icon className="text-primary-foreground" size={24} />
                  </div>

                  {/* File name */}
                  <p className="text-sm font-medium text-foreground text-center truncate mb-1">
                    {file.name}
                  </p>

                  {/* File info */}
                  <p className="text-xs text-muted-foreground text-center">
                    {file.size}
                  </p>

                  {/* Shared indicator */}
                  {file.shared && (
                    <div className="absolute bottom-2 left-2">
                      <Share2 className="text-neon-cyan" size={12} />
                    </div>
                  )}

                  {/* More options */}
                  <motion.button
                    className="absolute bottom-2 right-2 p-1.5 rounded-lg text-muted-foreground opacity-0 group-hover:opacity-100 hover:text-foreground hover:bg-muted transition-all"
                    onClick={(e) => {
                      e.stopPropagation()
                      setContextMenu({ id: file.id, x: e.clientX, y: e.clientY })
                    }}
                    whileHover={{ scale: 1.1 }}
                  >
                    <MoreVertical size={14} />
                  </motion.button>
                </motion.div>
              )
            })}
          </motion.div>
        ) : (
          <motion.div
            className="glass-card rounded-2xl overflow-hidden"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <table className="w-full">
              <thead>
                <tr className="text-left text-sm text-muted-foreground border-b border-border">
                  <th className="p-4 font-medium">Name</th>
                  <th className="p-4 font-medium hidden md:table-cell">Type</th>
                  <th className="p-4 font-medium">Size</th>
                  <th className="p-4 font-medium hidden sm:table-cell">Modified</th>
                  <th className="p-4 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {files.map((file, index) => {
                  const Icon = fileTypeIcons[file.type]
                  const isSelected = selectedFiles.includes(file.id)

                  return (
                    <motion.tr
                      key={file.id}
                      className={`border-b border-border/50 hover:bg-muted/30 transition-colors cursor-pointer ${
                        isSelected ? "bg-neon-cyan/10" : ""
                      }`}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.03 }}
                      onClick={() => toggleFileSelection(file.id)}
                    >
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${fileTypeColors[file.type]} flex items-center justify-center`}>
                            <Icon className="text-primary-foreground" size={18} />
                          </div>
                          <div>
                            <span className="font-medium text-foreground">{file.name}</span>
                            <div className="flex items-center gap-2">
                              {file.starred && <Star className="text-chart-4" size={12} fill="currentColor" />}
                              {file.shared && <Share2 className="text-neon-cyan" size={12} />}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-muted-foreground capitalize hidden md:table-cell">{file.type}</td>
                      <td className="p-4 text-muted-foreground">{file.size}</td>
                      <td className="p-4 text-muted-foreground hidden sm:table-cell">{file.modified}</td>
                      <td className="p-4">
                        <div className="flex items-center gap-1">
                          <motion.button
                            className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            onClick={(e) => e.stopPropagation()}
                          >
                            <Eye size={16} />
                          </motion.button>
                          <motion.button
                            className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            onClick={(e) => e.stopPropagation()}
                          >
                            <Download size={16} />
                          </motion.button>
                          <motion.button
                            className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            onClick={(e) => e.stopPropagation()}
                          >
                            <Share2 size={16} />
                          </motion.button>
                          <motion.button
                            className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-destructive"
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            onClick={(e) => e.stopPropagation()}
                          >
                            <Trash2 size={16} />
                          </motion.button>
                        </div>
                      </td>
                    </motion.tr>
                  )
                })}
              </tbody>
            </table>
          </motion.div>
        )}

        {/* Context Menu */}
        <AnimatePresence>
          {contextMenu && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setContextMenu(null)}
              />
              <motion.div
                className="fixed z-50 glass-card rounded-xl p-2 min-w-48 shadow-xl"
                style={{ left: contextMenu.x, top: contextMenu.y }}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
              >
                {[
                  { icon: Eye, label: "Preview" },
                  { icon: Download, label: "Download" },
                  { icon: Share2, label: "Share" },
                  { icon: Edit, label: "Rename" },
                  { icon: Copy, label: "Copy" },
                  { icon: Trash2, label: "Delete", danger: true },
                ].map((item) => (
                  <button
                    key={item.label}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                      item.danger
                        ? "text-destructive hover:bg-destructive/10"
                        : "text-foreground hover:bg-muted"
                    }`}
                    onClick={() => setContextMenu(null)}
                  >
                    <item.icon size={16} />
                    {item.label}
                  </button>
                ))}
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
