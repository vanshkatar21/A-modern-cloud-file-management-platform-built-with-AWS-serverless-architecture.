"use client"

import { motion } from "framer-motion"
import { DashboardHeader } from "@/components/dashboard-header"
import { GlowButton } from "@/components/glow-button"
import { useState } from "react"
import {
  User,
  Mail,
  Lock,
  Bell,
  Shield,
  Palette,
  Globe,
  CreditCard,
  Trash2,
  Camera,
  Check,
  ChevronRight,
  Smartphone,
  Key,
  Download,
  Upload,
} from "lucide-react"

const settingsTabs = [
  { id: "profile", label: "Profile", icon: User },
  { id: "security", label: "Security", icon: Shield },
  { id: "notifications", label: "Notifications", icon: Bell },
  { id: "billing", label: "Billing", icon: CreditCard },
  { id: "preferences", label: "Preferences", icon: Palette },
]

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("profile")
  const [profileData, setProfileData] = useState({
    name: "John Doe",
    email: "john.doe@example.com",
    username: "johndoe",
    bio: "Cloud enthusiast and developer",
    timezone: "UTC-5 (Eastern Time)",
    language: "English",
  })

  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    uploads: true,
    downloads: false,
    sharing: true,
    marketing: false,
  })

  const [twoFactor, setTwoFactor] = useState(false)

  return (
    <div className="min-h-screen">
      <DashboardHeader title="Settings" subtitle="Manage your account and preferences" />

      <div className="p-6">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-col lg:flex-row gap-6">
            {/* Sidebar Navigation */}
            <motion.div
              className="lg:w-64 flex-shrink-0"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <div className="glass-card rounded-2xl p-4">
                <nav className="space-y-1">
                  {settingsTabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                        activeTab === tab.id
                          ? "bg-gradient-to-r from-neon-blue/20 to-neon-cyan/20 text-foreground"
                          : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                      }`}
                    >
                      <tab.icon size={20} className={activeTab === tab.id ? "text-neon-cyan" : ""} />
                      <span className="font-medium">{tab.label}</span>
                      {activeTab === tab.id && (
                        <ChevronRight className="ml-auto text-neon-cyan" size={16} />
                      )}
                    </button>
                  ))}
                </nav>
              </div>
            </motion.div>

            {/* Content Area */}
            <motion.div
              className="flex-1"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              {/* Profile Tab */}
              {activeTab === "profile" && (
                <div className="space-y-6">
                  {/* Profile Picture */}
                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4">Profile Picture</h3>
                    <div className="flex items-center gap-6">
                      <div className="relative">
                        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-neon-blue to-neon-purple flex items-center justify-center text-3xl font-bold text-primary-foreground">
                          JD
                        </div>
                        <button className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-neon-cyan flex items-center justify-center text-primary-foreground hover:scale-110 transition-transform">
                          <Camera size={16} />
                        </button>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-2">
                          Upload a new avatar. Recommended size: 256x256px
                        </p>
                        <div className="flex gap-2">
                          <button className="px-4 py-2 rounded-lg glass text-sm hover:bg-muted/50 transition-colors">
                            Upload
                          </button>
                          <button className="px-4 py-2 rounded-lg text-sm text-destructive hover:bg-destructive/10 transition-colors">
                            Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Profile Information */}
                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4">Profile Information</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">Full Name</label>
                        <input
                          type="text"
                          value={profileData.name}
                          onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-neon-blue/50 focus:border-neon-blue transition-all"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">Username</label>
                        <input
                          type="text"
                          value={profileData.username}
                          onChange={(e) => setProfileData({ ...profileData, username: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-neon-blue/50 focus:border-neon-blue transition-all"
                        />
                      </div>
                      <div className="space-y-2 md:col-span-2">
                        <label className="text-sm font-medium text-foreground">Email</label>
                        <input
                          type="email"
                          value={profileData.email}
                          onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-neon-blue/50 focus:border-neon-blue transition-all"
                        />
                      </div>
                      <div className="space-y-2 md:col-span-2">
                        <label className="text-sm font-medium text-foreground">Bio</label>
                        <textarea
                          value={profileData.bio}
                          onChange={(e) => setProfileData({ ...profileData, bio: e.target.value })}
                          rows={3}
                          className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-neon-blue/50 focus:border-neon-blue transition-all resize-none"
                        />
                      </div>
                    </div>
                    <div className="mt-6">
                      <GlowButton variant="primary" size="sm">
                        Save Changes
                      </GlowButton>
                    </div>
                  </div>
                </div>
              )}

              {/* Security Tab */}
              {activeTab === "security" && (
                <div className="space-y-6">
                  {/* Password */}
                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4">Change Password</h3>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">Current Password</label>
                        <input
                          type="password"
                          placeholder="Enter current password"
                          className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-neon-blue/50 focus:border-neon-blue transition-all"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">New Password</label>
                        <input
                          type="password"
                          placeholder="Enter new password"
                          className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-neon-blue/50 focus:border-neon-blue transition-all"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">Confirm New Password</label>
                        <input
                          type="password"
                          placeholder="Confirm new password"
                          className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-neon-blue/50 focus:border-neon-blue transition-all"
                        />
                      </div>
                    </div>
                    <div className="mt-6">
                      <GlowButton variant="primary" size="sm">
                        Update Password
                      </GlowButton>
                    </div>
                  </div>

                  {/* Two-Factor Authentication */}
                  <div className="glass-card rounded-2xl p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-neon-blue to-neon-cyan flex items-center justify-center">
                          <Smartphone className="text-primary-foreground" size={20} />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-foreground">Two-Factor Authentication</h3>
                          <p className="text-sm text-muted-foreground mt-1">
                            Add an extra layer of security to your account
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => setTwoFactor(!twoFactor)}
                        className={`relative w-12 h-6 rounded-full transition-colors ${
                          twoFactor ? "bg-neon-cyan" : "bg-muted"
                        }`}
                      >
                        <motion.div
                          className="absolute top-1 w-4 h-4 rounded-full bg-primary-foreground"
                          animate={{ left: twoFactor ? "calc(100% - 20px)" : "4px" }}
                          transition={{ type: "spring", stiffness: 500, damping: 30 }}
                        />
                      </button>
                    </div>
                  </div>

                  {/* Active Sessions */}
                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4">Active Sessions</h3>
                    <div className="space-y-4">
                      {[
                        { device: "MacBook Pro", location: "New York, US", current: true },
                        { device: "iPhone 14", location: "New York, US", current: false },
                        { device: "Windows PC", location: "San Francisco, US", current: false },
                      ].map((session, index) => (
                        <div key={index} className="flex items-center justify-between p-4 rounded-xl bg-muted/30">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                              <Key className="text-muted-foreground" size={18} />
                            </div>
                            <div>
                              <p className="font-medium text-foreground">
                                {session.device}
                                {session.current && (
                                  <span className="ml-2 text-xs text-neon-cyan">(Current)</span>
                                )}
                              </p>
                              <p className="text-sm text-muted-foreground">{session.location}</p>
                            </div>
                          </div>
                          {!session.current && (
                            <button className="text-sm text-destructive hover:underline">
                              Revoke
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Notifications Tab */}
              {activeTab === "notifications" && (
                <div className="glass-card rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-foreground mb-6">Notification Preferences</h3>
                  <div className="space-y-4">
                    {[
                      { key: "email", label: "Email Notifications", description: "Receive notifications via email" },
                      { key: "push", label: "Push Notifications", description: "Receive push notifications in browser" },
                      { key: "uploads", label: "Upload Alerts", description: "Notify when uploads complete" },
                      { key: "downloads", label: "Download Alerts", description: "Notify when files are downloaded" },
                      { key: "sharing", label: "Sharing Updates", description: "Notify when files are shared" },
                      { key: "marketing", label: "Marketing Emails", description: "Receive product updates and offers" },
                    ].map((setting) => (
                      <div
                        key={setting.key}
                        className="flex items-center justify-between p-4 rounded-xl bg-muted/30"
                      >
                        <div>
                          <p className="font-medium text-foreground">{setting.label}</p>
                          <p className="text-sm text-muted-foreground">{setting.description}</p>
                        </div>
                        <button
                          onClick={() =>
                            setNotifications({
                              ...notifications,
                              [setting.key]: !notifications[setting.key as keyof typeof notifications],
                            })
                          }
                          className={`relative w-12 h-6 rounded-full transition-colors ${
                            notifications[setting.key as keyof typeof notifications] ? "bg-neon-cyan" : "bg-muted"
                          }`}
                        >
                          <motion.div
                            className="absolute top-1 w-4 h-4 rounded-full bg-primary-foreground"
                            animate={{
                              left: notifications[setting.key as keyof typeof notifications]
                                ? "calc(100% - 20px)"
                                : "4px",
                            }}
                            transition={{ type: "spring", stiffness: 500, damping: 30 }}
                          />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Billing Tab */}
              {activeTab === "billing" && (
                <div className="space-y-6">
                  {/* Current Plan */}
                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4">Current Plan</h3>
                    <div className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-neon-blue/20 to-neon-cyan/20 border border-neon-cyan/30">
                      <div>
                        <p className="text-xl font-bold text-gradient">Pro Plan</p>
                        <p className="text-sm text-muted-foreground">10 GB Storage - Billed Monthly</p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-foreground">$9.99</p>
                        <p className="text-sm text-muted-foreground">/month</p>
                      </div>
                    </div>
                    <div className="mt-4 flex gap-3">
                      <GlowButton variant="primary" size="sm">
                        Upgrade Plan
                      </GlowButton>
                      <button className="px-4 py-2 rounded-lg glass text-sm hover:bg-muted/50 transition-colors">
                        View Plans
                      </button>
                    </div>
                  </div>

                  {/* Payment Method */}
                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4">Payment Method</h3>
                    <div className="flex items-center justify-between p-4 rounded-xl bg-muted/30">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-8 rounded bg-gradient-to-r from-neon-blue to-neon-purple" />
                        <div>
                          <p className="font-medium text-foreground">Visa ending in 4242</p>
                          <p className="text-sm text-muted-foreground">Expires 12/2025</p>
                        </div>
                      </div>
                      <button className="text-sm text-neon-cyan hover:underline">Edit</button>
                    </div>
                  </div>

                  {/* Billing History */}
                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4">Billing History</h3>
                    <div className="space-y-3">
                      {[
                        { date: "Mar 1, 2024", amount: "$9.99", status: "Paid" },
                        { date: "Feb 1, 2024", amount: "$9.99", status: "Paid" },
                        { date: "Jan 1, 2024", amount: "$9.99", status: "Paid" },
                      ].map((invoice, index) => (
                        <div key={index} className="flex items-center justify-between p-3 rounded-xl hover:bg-muted/30 transition-colors">
                          <div>
                            <p className="font-medium text-foreground">{invoice.date}</p>
                            <p className="text-sm text-muted-foreground">Pro Plan - Monthly</p>
                          </div>
                          <div className="flex items-center gap-4">
                            <span className="text-foreground">{invoice.amount}</span>
                            <span className="text-xs px-2 py-1 rounded-full bg-chart-2/20 text-chart-2">
                              {invoice.status}
                            </span>
                            <button className="text-muted-foreground hover:text-foreground">
                              <Download size={16} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Preferences Tab */}
              {activeTab === "preferences" && (
                <div className="space-y-6">
                  {/* Language & Region */}
                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4">Language & Region</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">Language</label>
                        <select className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-neon-blue/50">
                          <option>English</option>
                          <option>Spanish</option>
                          <option>French</option>
                          <option>German</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">Timezone</label>
                        <select className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-neon-blue/50">
                          <option>UTC-5 (Eastern Time)</option>
                          <option>UTC-8 (Pacific Time)</option>
                          <option>UTC+0 (GMT)</option>
                          <option>UTC+5:30 (IST)</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Data & Privacy */}
                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4">Data & Privacy</h3>
                    <div className="space-y-4">
                      <button className="w-full flex items-center justify-between p-4 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors">
                        <div className="flex items-center gap-3">
                          <Download className="text-neon-cyan" size={20} />
                          <div className="text-left">
                            <p className="font-medium text-foreground">Export My Data</p>
                            <p className="text-sm text-muted-foreground">Download all your data</p>
                          </div>
                        </div>
                        <ChevronRight className="text-muted-foreground" size={20} />
                      </button>
                      <button className="w-full flex items-center justify-between p-4 rounded-xl bg-destructive/10 hover:bg-destructive/20 transition-colors">
                        <div className="flex items-center gap-3">
                          <Trash2 className="text-destructive" size={20} />
                          <div className="text-left">
                            <p className="font-medium text-destructive">Delete Account</p>
                            <p className="text-sm text-muted-foreground">Permanently delete your account</p>
                          </div>
                        </div>
                        <ChevronRight className="text-muted-foreground" size={20} />
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  )
}
