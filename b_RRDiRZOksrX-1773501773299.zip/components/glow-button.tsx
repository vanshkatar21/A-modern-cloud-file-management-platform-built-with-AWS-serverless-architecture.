"use client"

import { motion } from "framer-motion"
import { ButtonHTMLAttributes, ReactNode } from "react"

interface GlowButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode
  variant?: "primary" | "secondary" | "outline"
  size?: "sm" | "md" | "lg"
}

export function GlowButton({ 
  children, 
  variant = "primary", 
  size = "md",
  className = "",
  ...props 
}: GlowButtonProps) {
  const sizeClasses = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg"
  }

  const variantClasses = {
    primary: "bg-gradient-to-r from-neon-blue via-neon-cyan to-neon-purple text-primary-foreground",
    secondary: "bg-secondary text-secondary-foreground",
    outline: "bg-transparent border-2 border-neon-blue text-neon-blue"
  }

  return (
    <motion.button
      className={`
        relative overflow-hidden rounded-xl font-semibold
        ${sizeClasses[size]}
        ${variantClasses[variant]}
        ${className}
        transition-all duration-300
      `}
      whileHover={{ 
        scale: 1.05,
        boxShadow: variant === "primary" 
          ? "0 0 30px oklch(0.65 0.25 260 / 0.5), 0 0 60px oklch(0.75 0.18 200 / 0.3)"
          : "0 0 20px oklch(0.65 0.25 260 / 0.3)"
      }}
      whileTap={{ scale: 0.95 }}
      {...props}
    >
      {variant === "primary" && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
          initial={{ x: "-100%" }}
          whileHover={{ x: "100%" }}
          transition={{ duration: 0.5 }}
        />
      )}
      <span className="relative z-10">{children}</span>
    </motion.button>
  )
}
