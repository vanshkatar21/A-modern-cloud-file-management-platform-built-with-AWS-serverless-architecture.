"use client"

import { motion } from "framer-motion"

export function FloatingClouds() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Animated gradient orbs */}
      <motion.div
        className="absolute w-96 h-96 rounded-full bg-neon-blue/20 blur-3xl"
        style={{ top: "10%", left: "10%" }}
        animate={{
          x: [0, 100, 0],
          y: [0, 50, 0],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute w-80 h-80 rounded-full bg-neon-cyan/15 blur-3xl"
        style={{ top: "40%", right: "15%" }}
        animate={{
          x: [0, -80, 0],
          y: [0, 80, 0],
          scale: [1.2, 1, 1.2],
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute w-72 h-72 rounded-full bg-neon-purple/20 blur-3xl"
        style={{ bottom: "20%", left: "30%" }}
        animate={{
          x: [0, 60, 0],
          y: [0, -40, 0],
          scale: [1, 1.3, 1],
        }}
        transition={{
          duration: 18,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Cloud SVGs */}
      <motion.svg
        className="absolute opacity-10"
        style={{ top: "15%", left: "5%" }}
        width="200"
        height="120"
        viewBox="0 0 200 120"
        animate={{ x: [0, 50, 0], y: [0, 10, 0] }}
        transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
      >
        <path
          d="M160 80C180 80 195 65 195 50C195 35 180 20 160 20C155 10 145 5 130 5C110 5 95 18 92 35C85 30 75 28 65 30C45 35 30 52 30 72C30 77 35 80 40 80H160Z"
          fill="url(#cloudGradient1)"
        />
        <defs>
          <linearGradient id="cloudGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="oklch(0.65 0.25 260)" />
            <stop offset="100%" stopColor="oklch(0.75 0.18 200)" />
          </linearGradient>
        </defs>
      </motion.svg>

      <motion.svg
        className="absolute opacity-10"
        style={{ top: "60%", right: "10%" }}
        width="150"
        height="90"
        viewBox="0 0 200 120"
        animate={{ x: [0, -30, 0], y: [0, -15, 0] }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut", delay: 2 }}
      >
        <path
          d="M160 80C180 80 195 65 195 50C195 35 180 20 160 20C155 10 145 5 130 5C110 5 95 18 92 35C85 30 75 28 65 30C45 35 30 52 30 72C30 77 35 80 40 80H160Z"
          fill="url(#cloudGradient2)"
        />
        <defs>
          <linearGradient id="cloudGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="oklch(0.6 0.25 300)" />
            <stop offset="100%" stopColor="oklch(0.65 0.25 260)" />
          </linearGradient>
        </defs>
      </motion.svg>

      <motion.svg
        className="absolute opacity-5"
        style={{ bottom: "30%", left: "60%" }}
        width="180"
        height="100"
        viewBox="0 0 200 120"
        animate={{ x: [0, 40, 0], y: [0, 20, 0] }}
        transition={{ duration: 18, repeat: Infinity, ease: "easeInOut", delay: 5 }}
      >
        <path
          d="M160 80C180 80 195 65 195 50C195 35 180 20 160 20C155 10 145 5 130 5C110 5 95 18 92 35C85 30 75 28 65 30C45 35 30 52 30 72C30 77 35 80 40 80H160Z"
          fill="url(#cloudGradient3)"
        />
        <defs>
          <linearGradient id="cloudGradient3" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="oklch(0.75 0.18 200)" />
            <stop offset="100%" stopColor="oklch(0.6 0.25 300)" />
          </linearGradient>
        </defs>
      </motion.svg>

      {/* Grid lines */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div className="absolute inset-0" style={{
          backgroundImage: `
            linear-gradient(oklch(0.65 0.25 260) 1px, transparent 1px),
            linear-gradient(90deg, oklch(0.65 0.25 260) 1px, transparent 1px)
          `,
          backgroundSize: "100px 100px"
        }} />
      </div>
    </div>
  )
}
