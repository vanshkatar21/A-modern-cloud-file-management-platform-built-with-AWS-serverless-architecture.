"use client"

import { motion } from "framer-motion"
import { ReactNode } from "react"

interface FeatureCardProps {
  icon: ReactNode
  title: string
  description: string
  delay?: number
}

export function FeatureCard({ icon, title, description, delay = 0 }: FeatureCardProps) {
  return (
    <motion.div
      className="group relative p-6 rounded-2xl glass-card cursor-pointer"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ 
        y: -5,
        transition: { duration: 0.2 }
      }}
    >
      {/* Glow effect on hover */}
      <motion.div
        className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        style={{
          background: "linear-gradient(135deg, oklch(0.65 0.25 260 / 0.1), oklch(0.75 0.18 200 / 0.1))",
          boxShadow: "0 0 30px oklch(0.65 0.25 260 / 0.2)"
        }}
      />
      
      {/* Icon container */}
      <motion.div
        className="relative w-14 h-14 mb-4 rounded-xl flex items-center justify-center bg-gradient-to-br from-neon-blue/20 to-neon-cyan/20 text-neon-cyan"
        whileHover={{ rotate: 5, scale: 1.1 }}
        transition={{ type: "spring", stiffness: 300 }}
      >
        {icon}
      </motion.div>

      {/* Content */}
      <h3 className="relative text-lg font-semibold text-foreground mb-2 group-hover:text-gradient transition-all duration-300">
        {title}
      </h3>
      <p className="relative text-muted-foreground text-sm leading-relaxed">
        {description}
      </p>

      {/* Bottom border glow */}
      <motion.div
        className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0.5 bg-gradient-to-r from-neon-blue via-neon-cyan to-neon-purple group-hover:w-3/4 transition-all duration-300"
      />
    </motion.div>
  )
}
