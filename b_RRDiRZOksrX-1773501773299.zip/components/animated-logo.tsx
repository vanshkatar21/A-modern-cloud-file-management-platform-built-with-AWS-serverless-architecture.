"use client"

import { motion } from "framer-motion"

export function AnimatedLogo({ className = "" }: { className?: string }) {
  return (
    <motion.div
      className={`flex items-center gap-2 ${className}`}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <motion.div
        className="relative"
        animate={{ 
          rotateY: [0, 360],
        }}
        transition={{ 
          duration: 8,
          repeat: Infinity,
          ease: "linear"
        }}
        style={{ transformStyle: "preserve-3d" }}
      >
        <svg
          width="40"
          height="40"
          viewBox="0 0 40 40"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="drop-shadow-[0_0_10px_oklch(0.65_0.25_260)]"
        >
          <defs>
            <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="oklch(0.65 0.25 260)" />
              <stop offset="50%" stopColor="oklch(0.75 0.18 200)" />
              <stop offset="100%" stopColor="oklch(0.6 0.25 300)" />
            </linearGradient>
          </defs>
          <motion.path
            d="M20 4C12 4 6 10 6 17C6 21 8 24 11 26C11 26 10 30 8 33C11 32 15 30 17 28C18 28 19 28 20 28C28 28 34 22 34 17C34 10 28 4 20 4Z"
            fill="url(#logoGradient)"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 2, ease: "easeInOut" }}
          />
          <motion.circle
            cx="14"
            cy="17"
            r="2"
            fill="white"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 1, duration: 0.3 }}
          />
          <motion.circle
            cx="20"
            cy="17"
            r="2"
            fill="white"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 1.2, duration: 0.3 }}
          />
          <motion.circle
            cx="26"
            cy="17"
            r="2"
            fill="white"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 1.4, duration: 0.3 }}
          />
        </svg>
      </motion.div>
      <motion.span
        className="text-xl font-bold text-gradient"
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.3, duration: 0.5 }}
      >
        CloudSync AI
      </motion.span>
    </motion.div>
  )
}
