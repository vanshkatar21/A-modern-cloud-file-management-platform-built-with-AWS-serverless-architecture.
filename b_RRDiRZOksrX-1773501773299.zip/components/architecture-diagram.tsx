"use client"

import { motion } from "framer-motion"

const awsServices = [
  { name: "S3", label: "Storage", x: 10, y: 20 },
  { name: "Lambda", label: "Compute", x: 35, y: 10 },
  { name: "API GW", label: "Gateway", x: 60, y: 20 },
  { name: "DynamoDB", label: "Database", x: 85, y: 10 },
  { name: "Cognito", label: "Auth", x: 20, y: 70 },
  { name: "CloudFront", label: "CDN", x: 50, y: 80 },
  { name: "CloudWatch", label: "Monitor", x: 80, y: 70 },
]

export function ArchitectureDiagram() {
  return (
    <section className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gradient mb-4">
            AWS Cloud Architecture
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Built on enterprise-grade AWS infrastructure for maximum reliability and performance
          </p>
        </motion.div>

        <motion.div
          className="relative w-full h-96 rounded-3xl glass-card overflow-hidden"
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
        >
          {/* Connection lines */}
          <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <motion.line
              x1="18" y1="25" x2="35" y2="15"
              stroke="url(#lineGradient)" strokeWidth="0.3"
              initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }}
              transition={{ duration: 1, delay: 0.5 }}
            />
            <motion.line
              x1="43" y1="15" x2="60" y2="25"
              stroke="url(#lineGradient)" strokeWidth="0.3"
              initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }}
              transition={{ duration: 1, delay: 0.7 }}
            />
            <motion.line
              x1="68" y1="25" x2="85" y2="15"
              stroke="url(#lineGradient)" strokeWidth="0.3"
              initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }}
              transition={{ duration: 1, delay: 0.9 }}
            />
            <motion.line
              x1="25" y1="70" x2="50" y2="80"
              stroke="url(#lineGradient)" strokeWidth="0.3"
              initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }}
              transition={{ duration: 1, delay: 1.1 }}
            />
            <motion.line
              x1="55" y1="80" x2="80" y2="70"
              stroke="url(#lineGradient)" strokeWidth="0.3"
              initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }}
              transition={{ duration: 1, delay: 1.3 }}
            />
            <motion.line
              x1="35" y1="20" x2="25" y2="65"
              stroke="url(#lineGradient)" strokeWidth="0.3"
              initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }}
              transition={{ duration: 1, delay: 1.5 }}
            />
            <motion.line
              x1="60" y1="30" x2="55" y2="75"
              stroke="url(#lineGradient)" strokeWidth="0.3"
              initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }}
              transition={{ duration: 1, delay: 1.7 }}
            />
            <defs>
              <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="oklch(0.65 0.25 260)" />
                <stop offset="100%" stopColor="oklch(0.75 0.18 200)" />
              </linearGradient>
            </defs>
          </svg>

          {/* AWS Service nodes */}
          {awsServices.map((service, index) => (
            <motion.div
              key={service.name}
              className="absolute flex flex-col items-center"
              style={{ left: `${service.x}%`, top: `${service.y}%`, transform: "translate(-50%, -50%)" }}
              initial={{ opacity: 0, scale: 0 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 * index, type: "spring" }}
              whileHover={{ scale: 1.1 }}
            >
              <div className="w-12 h-12 md:w-16 md:h-16 rounded-xl bg-gradient-to-br from-neon-blue/30 to-neon-cyan/30 border border-neon-blue/40 flex items-center justify-center mb-2 glow-blue">
                <span className="text-xs md:text-sm font-bold text-neon-cyan">{service.name}</span>
              </div>
              <span className="text-xs text-muted-foreground">{service.label}</span>
            </motion.div>
          ))}

          {/* Center hub */}
          <motion.div
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5, type: "spring" }}
          >
            <div className="w-20 h-20 md:w-24 md:h-24 rounded-full bg-gradient-to-br from-neon-blue via-neon-cyan to-neon-purple flex items-center justify-center glow-cyan">
              <span className="text-sm md:text-base font-bold text-primary-foreground">CloudSync</span>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
